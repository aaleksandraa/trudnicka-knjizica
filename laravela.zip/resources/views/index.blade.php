@extends('layout')

@section('title', 'Home')

@section('content')
    @guest
        <script>window.location = "{{ route('login') }}";</script>
    @endguest

    @auth
                @if(auth()->user() && auth()->user()->SuperAdmin ?? false)

        
            <div class="container">
                <h2>Lista trudnica</h2>
                @if(isset($users) && count($users) > 0)
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ime i prezime</th>
                                <th>Datum Rodjenja</th>
                                <th>Adresa</th>
                                <th>Zanimanje</th>
                                <th>Telefon</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                                @if($user->SuperAdmin == 0)
                                    <tr onclick="window.location='{{ route('profile', $user->id) }}';">
                                        <td>{{ $user->ime }}</td>
                                        <td>{{ \Carbon\Carbon::parse($user->datum_rodjenja)->format('d.m.Y.') }}</td>
                                        <td>{{ $user->adresa }}</td>
                                        <td>{{ $user->zanimanje }}</td>
                                        <td>{{ $user->telefon }}</td>
                                        <td>{{ $user->email }}</td>
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <p>No users found.</p>
                @endif
            </div>
        @else
            <div class="container">
                <h1>Access Denied</h1>
                <p>You don't have permission to access this page.</p>
            </div>
        @endif
    @endauth
@endsection
