@extends('layouts/profile')

@section('title', 'Home')

@section('content')


@endsection