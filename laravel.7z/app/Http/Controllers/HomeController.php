<?php

namespace App\Http\Controllers;

use App\Models\User; // Add this line at the top of your HomeController

class HomeController extends Controller
{
    public function index()
    {
        if (auth()->user()->SuperAdmin) {
            $users = User::all(); // Assuming your User model is named "User"
            return view('index', compact('users'));
        } else {
            return view('index');
        }
    }
    


    
    // Your other methods...
}
